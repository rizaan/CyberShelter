# CyberShelter Report Week-0

# On-boarding Week (Days 0–7)

*Kali, Linux, networking and security basics, with completed daily reports and the Day 7 findings report*

**Submitted by:** Rizaan Mohammed

**Report date: 13 November 2026**

**Reviewed by:**

## Pre-Day 0 — Lab setup checklist

| Step | Setting / command | Done |
| --- | --- | --- |
| Install VirtualBox + Extension Pack | virtualbox.org/wiki/Downloads | ☐ |
| Kali ISO / pre-built VirtualBox image | kali.org/get-kali (use the VirtualBox image to save time) | ☐ |
| VM resources | 4 GB RAM · 2 vCPU · 40 GB dynamically-allocated disk | ☐ |
| Shared clipboard + drag & drop | Devices → Shared Clipboard → *Bidirectional*; Drag and Drop → *Bidirectional* (needs Guest Additions; pre-installed in Kali VM image) | ☐ |
| Update | `sudo apt update && sudo apt upgrade -y` | ☐ |
| Snapshot | Machine → Take Snapshot → "clean-install" (lets you roll back any mistake) | ☐ |

> 
> 
> 
> ![Screenshot 2026-11-09 230618.png](Screenshot_2026-11-09_230618.png)
> 

## Day 1 — System identification and how a computer boots

**System inventory.** The values below are typical for a Kali VM. Replace them with your own output.

| Item | Command | What to read | Example value |
| --- | --- | --- | --- |
| CPU model | `lscpu` | "Model name", "CPU(s)" | Intel Core i5-1135G7, 2 CPUs |
| RAM | `free -h` | "Mem: total" | 3.8 Gi |
| Disk partitions | `lsblk`, `df -h` | NAME/SIZE/MOUNTPOINT | sda (40G) → sda1 `/` (39G), swap |
| Kernel / OS | `uname -a` | kernel version, arch | 6.x.x-amd64 x86_64 GNU/Linux |
| USB devices | `lsusb` | IDs and names | VirtualBox USB Tablet, Linux root hubs |
| PCI devices | `lspci` | controllers | VGA (VMware SVGA II), Intel PRO/1000 NIC, AHCI SATA |
| Processes | `top`, `htop`, `ps aux` | CPU/mem hogs, PID, user | `systemd` = PID 1 |
| Boot logs | `dmesg | less`, `journalctl -xb` | kernel and current-boot messages | — |

![image.png](image.png)

**Write-up: how a system boots.**

1. **Power on and firmware.** The CPU starts running firmware code (BIOS or, on modern machines, UEFI) stored on the motherboard.
2. **POST.** The Power-On Self-Test checks that the CPU, RAM, video and storage controllers work. A failure here produces beep codes or an error before any OS loads.
3. **Boot device selection.** The firmware follows the configured boot order. BIOS reads the first 512-byte sector (MBR). UEFI reads a `.efi` bootloader from the EFI System Partition.
4. **Bootloader (GRUB).** GRUB shows the boot menu, then loads the Linux **kernel** (`vmlinuz`) and the **initramfs** (a small temporary root filesystem holding the drivers needed to mount the real disk) into RAM.
5. **Kernel.** The kernel decompresses itself, detects hardware (you see this in `dmesg`), mounts the initramfs, then mounts the real root filesystem `/`.
6. **Init (systemd, PID 1).** The kernel starts `/sbin/init`, which is systemd. systemd starts services in parallel to reach the default *target* (for example, `graphical.target`).
7. **Login.** The display manager (LightDM on Kali) or a getty TTY presents the login prompt, and the user's shell or desktop session starts.

## Day 2 — Linux fundamentals lab

**Security project directory structure.**

```bash
mkdir -p ~/security_project/{recon,scans,exploits,loot,reports,notes}
tree ~/security_project        # sudo apt install tree if missing
```

**Non-root user with scoped permissions.**

```bash
sudo useradd -m -s /bin/bash analyst      # create user with home dir
sudo passwd analyst                       # set password
sudo groupadd secteam                     # project group
sudo usermod -aG secteam analyst          # add analyst to group
sudo chown -R $USER:secteam ~/security_project
chmod -R 770 ~/security_project/reports   # owner+group full, others none
chmod 750 ~/security_project              # group can enter/read, not write top-level
id analyst                                # verify: groups=...secteam
ls -ld ~/security_project/*               # verify permissions
```

**Permission meaning:** `chmod 755` = owner `rwx` (4+2+1), group `r-x` (4+1), others `r-x`. `chown root:root file` makes root both the owning user and group. `kill -9 <pid>` sends SIGKILL, which cannot be caught. Try `kill <pid>` (SIGTERM) first so the process can clean up.

![image.png](image%201.png)

## Day 3 — Network identification and TCP vs UDP

| Item | Command | Example (VirtualBox NAT) |
| --- | --- | --- |
| IP address | `ip a` (look at `eth0` → `inet`) | 10.0.2.15/24 |
| Gateway | `ip route` (the `default via` line) | 10.0.2.2 |
| DNS server | `cat /etc/resolv.conf` or `nmcli dev show | grep DNS` | 10.0.2.3 |
| Listening ports | `ss -tulnp` | none or few on a fresh Kali |
| Connectivity | `ping -c 4 google.com`, `traceroute google.com`, `nslookup google.com` | replies, hop list, resolved IP |

**TCP vs UDP**

|  | TCP | UDP |
| --- | --- | --- |
| Connection | Connection-oriented (3-way handshake SYN → SYN-ACK → ACK) | Connectionless: just sends datagrams |
| Reliability | Guaranteed delivery, ordering, retransmission, flow control | No guarantees: packets can be lost or arrive out of order |
| Overhead / speed | Higher header (20 B+), slower | 8-byte header, faster, low latency |
| Used by | HTTP/HTTPS, SSH, SMTP, FTP, RDP | DNS queries, DHCP, VoIP, streaming, SNMP, gaming |
| Security angle | Handshake makes scanning detectable (SYN scans); session hijack possible | Easy to spoof source; used in amplification DDoS (DNS, NTP) |

## Day 4 — Packet capture: DNS, TCP handshake and why HTTPS is secure

**Steps:** run `sudo wireshark`, start capturing on `eth0`, browse to `http://testphp.vulnweb.com` and then `https://example.com`, and stop the capture.

- **DNS request:** filter `dns`. You see a *Standard query A testphp.vulnweb.com* from your IP to 10.0.2.3 over UDP 53, then a *Standard query response* with the IP.
- **TCP handshake:** filter `tcp.flags.syn==1 || (tcp.flags.ack==1 && tcp.len==0 && tcp.seq==1)`, or simply find the first three packets to port 80. They are **SYN** (client → server, seq=x), **SYN-ACK** (server → client, seq=y, ack=x+1) and **ACK** (client → server, ack=y+1).
- **HTTP vs HTTPS:** for HTTP, right-click → Follow → TCP Stream shows the full `GET /` request and HTML in clear text. For HTTPS, you only see TLS records ("Application Data") after the Client Hello and Server Hello.

**Why HTTPS is secure:** TLS gives **confidentiality**, because traffic is encrypted with a session key agreed during the handshake, so a sniffer sees ciphertext only. It gives **integrity**, because every record is authenticated, so tampering is detected. It gives **authenticity**, because the server presents a certificate signed by a trusted Certificate Authority, which proves you are talking to the real site and not a man-in-the-middle. Note that HTTPS does *not* hide the destination IP or (usually) the domain name in the SNI field.

**Service enumeration:** `nmap localhost` (usually all closed on fresh Kali). `nmap -sS -sV scanme.nmap.org` usually shows 22/ssh (OpenSSH), 80/http (Apache), 9929/nping-echo and 31337/tcpwrapped. scanme.nmap.org is explicitly authorised for scanning by the Nmap project. Never scan anything else without permission.

1.  (1) the DNS query/response,
2.  (2) the three handshake packets, 
3. (3) the Follow TCP Stream of the HTTP page.

![Screenshot From 2026-11-11 06-30-55.png](Screenshot_From_2026-11-11_06-30-55.png)

![Screenshot From 2026-11-11 06-32-25.png](Screenshot_From_2026-11-11_06-32-25.png)

![Screenshot From 2026-11-11 06-33-05.png](Screenshot_From_2026-11-11_06-33-05.png)

![Screenshot From 2026-11-11 06-33-59.png](Screenshot_From_2026-11-11_06-33-59.png)

## Day 5 — Hashing, password cracking, firewall

```bash
echo -n "password" | md5sum      # 5f4dcc3b5aa765d61d8327deb882cf99
echo -n "password" | sha256sum   # 5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8
```

Use `-n`. Without it, `echo` adds a newline and you hash `"password\n"`, which gives a different value.

**Crack a weak password (demo):**

![Screenshot From 2026-11-11 07-06-29.png](Screenshot_From_2026-11-11_07-06-29.png)

**Firewall:** `sudo ufw status` shows "inactive" by default on Kali. `sudo iptables -L` lists the INPUT/FORWARD/OUTPUT chains, which have policy ACCEPT by default. `hydra --help` covers online brute force against login services (SSH, FTP, HTTP forms). Only use it against your own lab targets.

**Hashing vs encryption**

|  | Hashing | Encryption |
| --- | --- | --- |
| Direction | One-way: cannot be reversed | Two-way: can be decrypted with the key |
| Key | No key (salt optional) | Needs a key (symmetric AES or asymmetric RSA) |
| Output | Fixed length, whatever the input size | Roughly the size of the input |
| Purpose | Integrity checks, password storage | Confidentiality of data |
| Examples | MD5 (broken), SHA-256, bcrypt, Argon2 | AES-256, RSA, ChaCha20 |

Passwords are **hashed** (with salt and a slow algorithm such as bcrypt or Argon2), never encrypted. John cracks a hash by hashing wordlist guesses until one matches, not by reversing it.

## Day 6 — Recon, scanning and the attack chain

| Step | Command | What you learn |
| --- | --- | --- |
| WHOIS | `whois google.com` | Registrar, creation/expiry dates, name servers |
| OSINT | `theHarvester -d google.com -b bing,duckduckgo` | Emails, sub-domains, hosts from public sources |
| Scan | `nmap -A scanme.nmap.org` | Open ports, versions, OS guess, traceroute, default NSE scripts |
| Web scan | `nikto -h http://testphp.vulnweb.com` | Outdated server, missing headers, interesting files |
| File triage | `file sample.bin`, `strings sample.bin | less` | Real file type (magic bytes), embedded URLs/commands |

**Attack chain (Recon → Scan → Exploit).**

1. **Reconnaissance (passive):** collect information without touching the target, such as WHOIS, DNS, OSINT and employee emails. The goal is to map the attack surface.
2. **Scanning and enumeration (active):** probe the target with nmap and nikto to find live hosts, open ports, service versions and known weaknesses.
3. **Exploitation:** use a vulnerability (for example an outdated service with a public CVE, weak credentials or SQL injection) to gain access.
4. **After exploitation:** privilege escalation, persistence, lateral movement and exfiltration. This maps onto the Lockheed Martin Kill Chain and the MITRE ATT&CK tactics.

Defenders break the chain early. Reduce public exposure, close unneeded ports, patch, and monitor for scanning activity.

## Day 7 — Mini-project: 1-page findings report

---

**SECURITY FINDINGS REPORT — Junior Analyst Assessment**

**Analyst:** Rizaan · **Date:** ____ · **Target:** scanme.nmap.org (authorised test host) · **Analyst host:** Kali Linux 

**1. Analyst system information.** OS: Kali GNU/Linux Rolling . IP: 172.20.10.4/28 , gateway 172.20.10.1, DNS 172.20.10.1. Listening services on analyst host: none exposed.

**2. Scope and method.** `nmap -sS -sV -O scanme.nmap.org`; `nmap -A scanme.nmap.org`;

**Limitations:**

Point-in-time, non-intrusive scan; no vulnerability or exploit testing. Scanning is permitted under Nmap’s terms for scanme.nmap.org.

**Risk rating:**

Qualitative, based on likelihood × impact.

Wireshark capture during the scan and during HTTP browsing of the target.

**3. Results.**

**OS detection:** Linux 

| Port | State | Service / version | Notes |
| --- | --- | --- | --- |
| 21/tcp | open | tcpwrapped | No banner returned; possibly a network-path artefact, verify from another network |
| 22/tcp | open | ssh - OpenSSH 6.6.1p1(ubuntu) | Remote admin exposed to internet |
| 80/tcp | open | Apache httpd 2.4.7 ((Ubuntu)) | Plain HTTP, no TLS |
| 9929/tcp | open | nping-echo | Test service |

**4. Traffic observations.** DNS lookup of the target over UDP/53. Open ports replied SYN/ACK (the scanner then sent RST), closed ports replied RST/ACK, and filtered ports gave no reply. The HTTP page was readable in plaintext with Follow TCP Stream.

![image.png](image%202.png)

Figure 1: SYN packets filtered in Wireshark (`tcp.flags.syn==1 && tcp.flags.ack==0`).

**5. Risks identified.**

| # | Finding | Risk | Recommendation |
| --- | --- | --- | --- |
| 1 | Outdated/EOL software (OpenSSH 6.6.1p1, Apache 2.4.7, Ubuntu 14.04) | High | Upgrade to a supported OS; patch regularly |
| 2 | Unencrypted HTTP | Medium | HTTPS, 80→443 redirect, HSTS |
| 3 | SSH exposed to internet | Medium | Keys only, no root login, fail2ban, IP/VPN restriction |
| 4 | Version banners disclosed | Low | Minimise banners (`ServerTokens Prod`) |
| 5 | Extra open ports (9929, 21?) | Low/Info | Close what isn’t required; verify port 21 |

**6. Conclusion.** The host exposes a small attack surface typical of a test server. The priority fixes are encrypting web traffic and hardening SSH. Re-scan after the fixes to verify.

---